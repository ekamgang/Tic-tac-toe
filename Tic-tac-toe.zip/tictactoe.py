"""
Tic Tac Toe Player
"""
import copy
import math
import numpy

X = "X"
O = "O"
EMPTY = None


def initial_state():
    """
    Returns starting state of the board.
    """
    return [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]


def player(board):
    """
    Returns player who has the next turn on a board.
    """
    if terminal(board):
        return -2
    if board==initial_state():
        return X
    #traverse entire board
    Xcount=0
    Ocount=0

    for i in range(len(board)):
     for j in range(len(board[i])):
        if board[i][j]== X:
            Xcount+=1
        if board[i][j]==O:
            Ocount+=1
    #if every cell is empty or number of X=number of O => X turn
    #if number of X > number of O => O turn
    if Xcount == Ocount :
        #return player X turn
        return X

    if Xcount>Ocount:
        #return player O turn
        return O


def actions(board):
    """
    Returns set of all possible actions (i, j) available on the board.
    """
    if terminal(board):
        return -2
        #Traverse board,if cell not X or O add to set
    moves = set()
    for i in range(len(board)):
     for j in range(len(board[i])):
        if board[i][j]== EMPTY:
            moves.add((i,j))
    return moves


def result(board, action):
    """
    Returns the board that results from making move (i, j) on the board.
    """
    l = actions(board)
    if action in l==False:
        raise NotImplementedError
    #create new board#deep copy current board
    newBoard = copy.deepcopy(board)
    #perform action at (action[0],action[1]) on new board
    i=action[0]
    j=action[1]
    newBoard[i][j]=player(board)
    #return new board
    return newBoard


def winner(board):
        """
        Returns the winner of the game, if there is one.
        """

        #create tuple [X,X,X] and {O,O,O} if tuples in board
        Xwin = [X,X,X]
        Owin = [O,O,O]
        dig1 = ([board[i][i] for i in range(len(board))])
        dig2 = ([board[j][len(board) - 1 - j] for j in range(len(board))])
        Board2 = copy.deepcopy(board)
        Tboard = numpy.transpose(Board2)
        if (dig1 == Xwin) or (dig2 == Xwin):
            return X
        elif(dig1 == Owin) or (dig1 == Owin):
            return O
        elif True:
            for a in range(len(board)):
                    if board[a][0]==X and board[a][1]==X and board[a][2]==X:
                        return X
                    elif board[a][0]==O and board[a][1]==O and board[a][2]==O:
                        return O
            for B in range(len(Tboard)):
                if Tboard[B][0] == X and Tboard[B][1] == X and Tboard[B][2] == X:
                    return X
                elif Tboard[B][0] == O and Tboard[B][1] == O and Tboard[B][2] == O:
                    return O
        else:

            return None

        """
        if (Xwin in board) or (dig1 == Xwin) or (dig2 == Xwin) or (Xwin in Tboard):
            return X
        elif (Owin in board) or (dig1 == Owin) or (dig1 == Owin) or (Owin in Tboard):
            return O
        else:
            return None
            """



def terminal(board):
    """
    Returns True if game is over, False otherwise.
    """

    if winner(board) == X or winner(board)==O:
        return True
    else:
     for x in range(len(board)):
            if EMPTY in board[x]:
                return False
     return True

def utility(board):
    """
    Returns 1 if X has won the game, -1 if O has won, 0 otherwise.
    """
    if winner(board)== X:
        return 1
    elif winner(board)== O:
        return -1
    else:
        return 0


def minimax(board):
    #create a dictionary of actions and their utilities
    #foe each action in actions find utility and add to dictionary
    #return smallest
    #why does max/min v it return a list

    def max_value(board):
        if terminal(board):

            return utility(board)
        else:
            v = -math.inf
            finalAct=[]
            for action in actions(board):
                newV=min_value(result(board, action))
                if type(newV)==tuple:
                    newV=newV[0]
                if v<newV:
                    v = newV
                    finalAct=action
            FAct=tuple(finalAct)
            return v,FAct

    def min_value(board):
        if terminal(board):
            return utility(board)
        else:
            v = math.inf
            finalAct = []
            for action in actions(board):
                newV=max_value(result(board, action))
                if type(newV)==tuple:
                    newV=newV[0]

                if v > newV:
                    v = newV
                    finalAct = action
            FAct = tuple(finalAct)
            return v,FAct


    if player(board)==X:
        return max_value(board)[1]
    else:
        return min_value(board)[1]



